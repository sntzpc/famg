// FG2026 - Standalone Live Map Config
// Ubah hanya bagian URL jika diperlukan (GAS Web App).
window.AppConfig = {
  api: {
    url: "https://script.google.com/macros/s/AKfycbynPeuvLZITK5deJbY115fkZ1CjnFQeUbb_NYPy1zut10W2h8OXnePyBwCm5fzRlWENaQ/exec"
  },
  app: {
    brand: {
      appName: "Family Gathering KMP1 2026"
    }
  }
};
