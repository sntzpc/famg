// FG2026 - Standalone Live Map Config
// Ubah hanya bagian URL jika diperlukan (GAS Web App).
window.AppConfig = {
  api: {
    url: "https://script.google.com/macros/s/AKfycbwA7SzOOcOxI21Zm0CYW7TTBuMftWShOA1pSfShrJzsPZB_j5We0rhKTnMaV9BMvnA/exec"
  },
  app: {
    brand: {
      appName: "Family Gathering KMP1 2026"
    }
  }
};
