// FG2026 - Standalone Live Map Config
// Ubah hanya bagian URL jika diperlukan (GAS Web App).
window.AppConfig = {
  api: {
    url: "https://script.google.com/macros/s/AKfycbzy7YUqDmGNnCpIwn2fyE54JEA0wlKsGP4yGzlEIlXlP2Oo4k0KZ1uAOJUK1llEL1Nb3w/exec"
  },
  app: {
    brand: {
      appName: "Family Gathering KMP1 2026"
    }
  }
};
